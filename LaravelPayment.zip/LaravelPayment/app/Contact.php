<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Contact extends Model
{
    protected $fillable = [
        'CardNumber',
        'CardHolder',
        'ExpiryDate',
        'SecurityCode',
        'amount',
        'identification'       
    ];
}